<?php
/**
 * Template for displaying sidebar forms in Bacardi theme
 *
 * @package WordPress
 * @subpackage Bacardi theme
 * @since Bacardi theme 1.0
 */
?>

<ul id="sidebar">
	<?php dynamic_sidebar( 'sidebar-bacardi' ); ?>
</ul>
